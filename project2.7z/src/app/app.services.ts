import { Injectable } from "@angular/core";
import { init } from "./app-init";

@Injectable({
    providedIn: 'root'
})

export class appservice extends init{
    //id!: number;
    constructor(){
        super();
        console.log('App service works')
        this.load()
    }
    //get
    getstudent(){
        let item=JSON.parse(localStorage.getItem('itemsarray')||'{}')
        return item;
    }
    //addstudent
    addstudent(newdata:any){
        //debugger;
        let items=JSON.parse(localStorage.getItem('itemsarray') || '{}')
        items.push(newdata)
        localStorage.setItem('itemsarray',JSON.stringify(items))
        
    }

    //Delete Student
    deletestudent(id: any){
    debugger;
    let items=JSON.parse(localStorage.getItem('itemsarray')|| '{}')
    for(let i=0;i<items.length;i++){
        if(items[i].id== id){
            items.splice(i,1)
        }
    }
    localStorage.setItem('itemsarray',JSON.stringify(items))
    }

    //Update
    updatestudent(olddata: any, newdata: any){  
    debugger;
    let items = JSON.parse(localStorage.getItem('itemsarray') || '{}');
    for(let i = 0; i <items.length; i++) {
     if(items[i].id == olddata) {
        items[i].id == newdata;
     }
    }
    localStorage.setItem('itemsarray', JSON.stringify(items));
  }


    
}