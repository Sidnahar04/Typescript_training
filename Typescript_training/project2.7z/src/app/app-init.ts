import { setConstantValue } from "typescript";


export class init{
    load(){
        if(localStorage.getItem('itemsarray')===null|| localStorage.getItem('itemsarray')==undefined){
            console.log("no Students found")
            let items=[
                {
                    id:1,
                    name:'Rahul1',
                    email:'rahul@gmail.com',
                    gender:'Male',
                    grade:8
                }
            ]
            localStorage.setItem('itemsarray',JSON.stringify(items) );
           
            return
        }
        else{
            console.log('found employees')
        }
    }
}