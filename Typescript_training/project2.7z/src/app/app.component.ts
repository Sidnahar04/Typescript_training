import { Component, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators} from "@angular/forms";
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { UUID } from 'angular2-uuid';
import { appservice } from './app.services';



export interface items {
  id:any,
  name:string,
  gender:string,
  email:string,
  grade:number
}


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  itemsarray:items[]=[];
  
  displayedcolumns=['Name','Email','Gender','Grade','Edit','Delete']
  
  datasource!: MatTableDataSource<items>;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  p:any;
  isedit!:boolean;
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  myForm!: FormGroup;
  @ViewChild('chipList',{ static: true}) chipList: any ;
  GradeArray: any = ['8th Grade', '9th Grade', '10th Grade', '11th Grade', '12th Grade'];
  title: any;
  uuidValue: any;
  //id: any;
  appState='default';
  oldstudent: any
  items: any;
  item!: items;


  constructor(public fb: FormBuilder,private appservice:appservice) {}
  generateUUID(){
    this.uuidValue=UUID.UUID();
    return this.uuidValue;
  }

  ngOnInit(){
    this.items=this.appservice.getstudent()
    this.datasource= new MatTableDataSource(this.items)
    this.reactiveForm()
    
  }
  /* Reactive form */
  reactiveForm() {
    this.myForm = this.fb.group({
      id:this.generateUUID(),
      name: ['',{Validators:[Validators.required]}],
      email: ['',{Validators:[Validators.required]}],
      gender: [''],  
      grade: ['',{Validators:[Validators.required]}],
    })
   
  }
  
  submitForm() {
      var newitems={
      id:this.myForm.value.id,
      name:this.myForm.value.name,
      email:this.myForm.value.email,
      gender:this.myForm.value.gender,
      grade:this.myForm.value.grade,
      }
    this.appservice.addstudent(newitems) 
    location.reload();  
  }
    
  reset(){
    this.myForm.reset()
  }

  editstudent(id:any){
    //debugger;
    this.item=this.items.find((p: { id: any; })=> p.id==id);
    this.myForm.setValue(this.item)
    //console.log(this.item) 
  }

  updatestudent(){
    //debugger;
    if(this.myForm.value){
      console.log(this.myForm.value)
      this.myForm.patchValue(this.myForm.value)
      this.appservice.updatestudent(this.item,this.myForm.value)
     }
  }


  deletestudent(id:any){
    debugger;
    this.appservice.deletestudent(id)
  }

}

























